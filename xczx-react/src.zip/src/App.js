import Routes from './router/routes';

function App() {
  return (
    <div className="App">
      <Routes />
    </div>
  );
}

export default App;

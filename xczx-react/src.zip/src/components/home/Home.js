import React from 'react';
import HomeBanner from './homeCarousel';
import './Home.css';
import { fieldSuggested } from '../../constants/home';

const Home = () => {
  const getFieldSuggestion = () => {
    return (
      <div className="card flex space-between">
        <dl className="flex">
          <dt>{fieldSuggested.title}</dt>
          {fieldSuggested.suggestedFields.map((field) => (
            <dd key={field}>
              <a href='/#'>{field}</a>
            </dd>
          ))}
        </dl>
        <div className="modify-interested-field">
          <a href='.#'>修改兴趣</a>
        </div>
      </div>
    );
  };
  return (
    <div className="homepage relative">
      <HomeBanner />
      <div className="container">{getFieldSuggestion()}</div>
    </div>
  );
};

export default Home;

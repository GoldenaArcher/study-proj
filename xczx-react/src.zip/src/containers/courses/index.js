import React from 'react';
import HeaderFooterHOC from '../../common/renderWithHeaderFooter';

const Courses = () => {
  return <div>courses</div>;
};

export default HeaderFooterHOC(Courses);

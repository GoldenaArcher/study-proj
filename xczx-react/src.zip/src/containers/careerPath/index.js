import React from 'react';
import HeaderFooterHOC from '../../common/renderWithHeaderFooter';

const CareerPath = () => {
  return <div>career-path</div>;
};

export default HeaderFooterHOC(CareerPath);

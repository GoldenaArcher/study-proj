import React from 'react';
import HeaderFooterHOC from '../../common/renderWithHeaderFooter';

const Course = () => {
  return <div>course</div>;
};

export default HeaderFooterHOC(Course);
